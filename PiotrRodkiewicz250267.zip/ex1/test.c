#include <stdio.h>
#include <math.h>

double f(double x){
    if(x >= -5 && x <= 5){
        return 2*x*x + 3*x -1;
    }
    return (x+5)*(x+5)-1;
}

int main(int argc, char** argv){

    printf("%s\n", "------------------1-------------------");

    char input[100];
    printf("%s\n","HelloWorld!");
    scanf("%s", input);
    printf("%s\n", input);

    printf("%s\n", "------------------2-------------------");

    printf("%s,%d\n", "An area of triangle with sides length 5,12,13: ", 5*12);

    printf("%s\n", "------------------3-------------------");

    float a,b;
    printf("%s", "Provide 2 numbers to calculate their avarage:");
    scanf("%f%f", &a, &b);
    printf("Their arithmetic avarage is:%f\n", (a+b)/2);

    printf("%s\n", "------------------4-------------------");

    printf("%s", "Provide two numbers to check the identity (a+b)(a-b)=a^2-b^2: ");
    scanf("%f%f", &a, &b);
    printf("(%f+%f)(%f-%f)=%f\n%f^2-%f^2=%f\n", a, b, a, b, (a+b)*(a-b), a,b, a*a - b*b);

    printf("%s\n", "------------------5-------------------");

    printf("%s", "Provide sides a and b of the right triangle: ");
    scanf("%f%f", &a, &b);
    printf("%s: %f, %s: %d, %f, %f", "The hypotenuse of the triangle is: ", sqrt(a*a+b*b), "The angles are:", 90, asin(a/b)/3.1417*180, 90-(asin(a/b))/3.1417*180);

    printf("%s\n", "------------------6-------------------");

    printf("for the function: \n%s\nthe following are its values for x c [-10;10]\n", "f(x)=2x^2+3x-1 for x c [-5;5] and\nf(x)=(x+5)^2-1 for x c (-inf;-5) or (5;inf)");
    printf("|\tx\t|\tf(x)\t|\n");
    for(float x=-10; x<=10; x+=0.5f){
        printf("|\t%.1f\t|\t%.2f\t|\n", x, f(x));
    }

    return 0;
}