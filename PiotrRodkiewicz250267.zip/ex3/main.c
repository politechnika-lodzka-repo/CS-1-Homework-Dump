#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

void assignString(char s[], char assigned[]){
    for(int i=0;i<100;i++){
        s[i]=assigned[i];
    }
}

int main(int argc, char** argv){
    printf("ex1:\nenter number of students and their names, surnames and adresses: \n");
    int n;
    scanf("%d", &n);
    
    char students[3*n][100];

    for(int i=0;i<n;i++){
        char name[100], surname[100];
        char* adress;
        size_t foo=100;
        adress = (char *)malloc(foo * sizeof(char));
        scanf("%s%s", name, surname);
        getline(&adress, &foo, stdin);
        assignString(students[3*i], name);
        assignString(students[3*i+1], surname);
        assignString(students[3*i+2], adress);
    }

    for(int i=0;i<n;i++){
        printf("name: %s\t tsurname: %s\t adress: %s\n", students[3*i], students[3*i+1], students[3*i+2]);
    }


    printf("ex2:\nenter dimmenstions of a 2d matrix:\n");
    int x,y;
    scanf("%d%d", &x, &y);
    int A[x][y];
    for(int i=0;i<x;i++){
        for(int j=0;j<y;j++){
            scanf("%d", &A[i][j]);
        }
    }

    printf("ex2: matrix of the sum of the row elemets:\n");
    for(int i=0;i<x;i++){
        int sum=0;
        for(int j=0;j<y;j++){
            sum+=A[i][j];
        }
        printf("[%d]\n", sum);
    }

    printf("ex2: matrix of the sum of the collumn elemets:\n");
    for(int i=0;i<y;i++){
        int sum=0;
        for(int j=0;j<x;j++){
            sum+=A[j][i];
        }
        printf("[%d]", sum);
    }
    printf("\n");




    return 0;
}